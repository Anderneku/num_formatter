This allows you to separate your numbers with commas for easy reading and better legibility

# Use
```python
import number_formatter

number = 100000

print(number_formatter.num_format(number)) #Prints out '100,000'